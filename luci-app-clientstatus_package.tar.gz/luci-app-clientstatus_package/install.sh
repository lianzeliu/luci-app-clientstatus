#!/bin/sh
# clientstatus 一键安装 (C daemon + LuCI JS view 版)
# 用法: ./install.sh [install|uninstall], 无参数默认安装
cd "$(dirname "$0")"

ACTION="${1:-install}"
JS_DIR="/www/luci-static/resources/view/services"

do_install() {
    echo "== 安装 clientstatus (C daemon + JS UI)..."

    mkdir -p /usr/bin
    mkdir -p /usr/lib/lua/luci/controller
    mkdir -p "$JS_DIR"
    mkdir -p /usr/lib/lua/luci/i18n
    mkdir -p /etc/init.d
    mkdir -p /etc/config

    # 停掉旧服务
    /etc/init.d/clientstatus stop 2>/dev/null || true

    cp -f clientstatus            /usr/bin/clientstatus
    cp -f clientstatus.lua       /usr/lib/lua/luci/controller/
    cp -f clientstatus_view.js   "$JS_DIR/clientstatus.js"
    cp -f clientstatus_settings_view.js "$JS_DIR/clientstatus_settings.js"
    [ -f clientstatus.zh-cn.lmo ] && cp -f clientstatus.zh-cn.lmo /usr/lib/lua/luci/i18n/
    cp -f clientstatus.init     /etc/init.d/clientstatus
    # 配置文件不存在才写入, 保留用户已有配置
    [ -f /etc/config/clientstatus ] || cp -f clientstatus.conf /etc/config/clientstatus

    chmod +x /usr/bin/clientstatus
    chmod +x /etc/init.d/clientstatus

    # 清理旧版残留 (Lua view / CBI)
    rm -f /usr/bin/clientstatus.sh
    rm -f /usr/lib/lua/luci/view/clientstatus.htm
    rm -f /usr/lib/lua/luci/model/cbi/clientstatus/settings.lua
    rm -rf /usr/lib/lua/luci/model/cbi/clientstatus

    /etc/init.d/clientstatus enable
    /etc/init.d/clientstatus start
    [ -x /etc/init.d/uhttpd ] && /etc/init.d/uhttpd restart 2>/dev/null || true

    echo "== 安装完成 ✅ =="
    echo "   LuCI: 服务 -> 客户端状态"
}

do_uninstall() {
    echo "== 卸载 clientstatus..."

    /etc/init.d/clientstatus stop 2>/dev/null || true
    /etc/init.d/clientstatus disable 2>/dev/null || true

    # 清理 nft 表
    nft delete table inet cs_traffic 2>/dev/null || true

    rm -f /usr/bin/clientstatus
    rm -f /usr/bin/clientstatus.sh
    rm -f /usr/lib/lua/luci/controller/clientstatus.lua
    rm -f "$JS_DIR/clientstatus.js"
    rm -f "$JS_DIR/clientstatus_settings.js"
    rm -f /usr/lib/lua/luci/view/clientstatus.htm
    rm -rf /usr/lib/lua/luci/model/cbi/clientstatus
    rm -f /usr/lib/lua/luci/i18n/clientstatus.zh-cn.lmo
    rm -f /etc/init.d/clientstatus
    # 保留 /etc/config/clientstatus (用户配置)

    echo "== 卸载完成 ✅ =="
}

case "$ACTION" in
    install|1)   do_install ;;
    uninstall|2) do_uninstall ;;
    *) echo "用法: $0 [install|uninstall]"; exit 1 ;;
esac
