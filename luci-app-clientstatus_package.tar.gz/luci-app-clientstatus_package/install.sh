#!/bin/sh
# clientstatus 一键安装 (C daemon 版)
# 用法: ./install.sh [install|uninstall], 无参数默认安装
cd "$(dirname "$0")"

ACTION="${1:-install}"

do_install() {
    echo "== 安装 clientstatus (C daemon)..."

    mkdir -p /usr/bin
    mkdir -p /usr/lib/lua/luci/controller
    mkdir -p /usr/lib/lua/luci/view
    mkdir -p /usr/lib/lua/luci/model/cbi/clientstatus
    mkdir -p /usr/lib/lua/luci/i18n
    mkdir -p /etc/init.d
    mkdir -p /etc/config

    # 停掉旧服务
    /etc/init.d/clientstatus stop 2>/dev/null || true

    cp -f clientstatus            /usr/bin/clientstatus
    cp -f clientstatus.lua       /usr/lib/lua/luci/controller/
    cp -f clientstatus.htm       /usr/lib/lua/luci/view/
    cp -f settings.lua          /usr/lib/lua/luci/model/cbi/clientstatus/
    [ -f clientstatus.zh-cn.lmo ] && cp -f clientstatus.zh-cn.lmo /usr/lib/lua/luci/i18n/
    cp -f clientstatus.init     /etc/init.d/clientstatus
    # 配置文件不存在才写入, 保留用户已有配置
    [ -f /etc/config/clientstatus ] || cp -f clientstatus.conf /etc/config/clientstatus

    chmod +x /usr/bin/clientstatus
    chmod +x /etc/init.d/clientstatus

    # 清理旧 shell 版残留
    rm -f /usr/bin/clientstatus.sh

    /etc/init.d/clientstatus enable
    /etc/init.d/clientstatus start
    [ -x /etc/init.d/uhttpd ] && /etc/init.d/uhttpd restart 2>/dev/null || true

    echo "== 安装完成 ✅ =="
    echo "   LuCI: 服务 -> 客户端状态"
    echo "   验证: cat /tmp/clientstatus.traffic"
}

do_uninstall() {
    echo "== 卸载 clientstatus..."

    /etc/init.d/clientstatus stop 2>/dev/null || true
    /etc/init.d/clientstatus disable 2>/dev/null || true

    # 清理 nft 表
    nft delete table inet cs_traffic 2>/dev/null || true

    rm -f /usr/bin/clientstatus
    rm -f /usr/bin/clientstatus.sh
    rm -f /usr/lib/lua/luci/controller/clientstatus.lua
    rm -f /usr/lib/lua/luci/view/clientstatus.htm
    rm -f /usr/lib/lua/luci/model/cbi/clientstatus/settings.lua
    rm -f /usr/lib/lua/luci/i18n/clientstatus.zh-cn.lmo
    rm -f /etc/init.d/clientstatus
    # 保留 /etc/config/clientstatus (用户配置)

    echo "== 卸载完成 ✅ =="
}

case "$ACTION" in
    install|1)   do_install ;;
    uninstall|2) do_uninstall ;;
    *) echo "用法: $0 [install|uninstall]"; exit 1 ;;
esac
