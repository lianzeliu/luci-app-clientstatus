#!/bin/sh
cd "$(dirname "$0")"
ACTION="${1:-install}"
JS_DIR="/www/luci-static/resources/view/services"
do_install() {
    echo "== 安装 clientstatus (JS UI)..."
    mkdir -p /usr/bin /usr/lib/lua/luci/controller "$JS_DIR" /etc/init.d /etc/config
    /etc/init.d/clientstatus stop 2>/dev/null || true
    # 杀掉残留进程 (防多实例)
    pkill -9 clientstatus 2>/dev/null || true
    sleep 1
    cp -f clientstatus /usr/bin/clientstatus
    cp -f clientstatus.lua /usr/lib/lua/luci/controller/
    cp -f clientstatus_view.js "$JS_DIR/clientstatus.js"
    cp -f clientstatus_settings_view.js "$JS_DIR/clientstatus_settings.js"
    cp -f clientstatus.init /etc/init.d/clientstatus
    [ -f /etc/config/clientstatus ] || cp -f clientstatus.conf /etc/config/clientstatus
    chmod +x /usr/bin/clientstatus /etc/init.d/clientstatus
    rm -f /usr/lib/lua/luci/view/clientstatus.htm
    rm -rf /usr/lib/lua/luci/model/cbi/clientstatus
    rm -f /usr/bin/clientstatus.sh
    # 清理旧 nft 表 (防重复规则)
    nft delete table inet cs_traffic 2>/dev/null || true
    /etc/init.d/clientstatus enable
    /etc/init.d/clientstatus start
    [ -x /etc/init.d/uhttpd ] && /etc/init.d/uhttpd restart 2>/dev/null || true
    echo "== 安装完成 =="
}
do_uninstall() {
    /etc/init.d/clientstatus stop 2>/dev/null || true
    pkill -9 clientstatus 2>/dev/null || true
    nft delete table inet cs_traffic 2>/dev/null || true
    rm -f /usr/bin/clientstatus /usr/lib/lua/luci/controller/clientstatus.lua
    rm -f "$JS_DIR/clientstatus.js" "$JS_DIR/clientstatus_settings.js"
    rm -f /etc/init.d/clientstatus
    echo "== 卸载完成 =="
}
case "$ACTION" in install|1) do_install;; uninstall|2) do_uninstall;; *) echo "用法: $0 [install|uninstall]";; esac
